<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

class RJsonwalksWalkWalk { 

    public $shape;
    public $nationalGrade;
    public $localGrade;
    public $distanceKm;
    public $pace;
    public $ascentMetres;

}
