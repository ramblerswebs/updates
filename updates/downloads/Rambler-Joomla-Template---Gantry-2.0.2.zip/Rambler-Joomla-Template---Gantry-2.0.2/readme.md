Reandme

Modified version of Gantry