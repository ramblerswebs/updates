<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of basics
 *
 * @author chris
 */
class RJsonwalksWalkContact {

    public $isLeader = false;       // is the contact info for the leader of the walk
    public $contactName = "";       // contact name
    public $email = "";             // email address for contact
    public $telephone1 = "";        // first telephone number of contact
    public $telephone2 = "";        // second telephone number of contact
    public $walkLeader = '';
    public $contactForm = "";       // The contact form on the Ramblers Site

}
