# RA Walks Editor
Version for Joomla 5


