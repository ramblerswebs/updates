DROP TABLE IF EXISTS `#__ra_groups`
