DROP TABLE IF EXISTS `#__ra_walks_editor_walks`;
DROP TABLE IF EXISTS `#__ra_walks_editor_places`;
DROP TABLE IF EXISTS `#__ra_walks_editor_contacts`;
DROP TABLE IF EXISTS `#__ra_walks_editor_grades`;
