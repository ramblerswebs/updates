<?php


class JRamblersWalksfeedLocation {

    public $gridref;
    public $longitude;
    public $latitude;
    public $postcode;

    function __construct($coordinates) {
        $this->latitude = $coordinates[0];
        $this->longitude = $coordinates[1];
        $this->postcode = "";
        $this->gridref = "";
    }

    function __destruct() {
        
    }

}
