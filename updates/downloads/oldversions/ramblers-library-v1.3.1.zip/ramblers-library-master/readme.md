Ramblers library to process and display json walks feeds

See wiki for details https://github.com/ramblerswebs/ramblers-library/wiki


