<?php
class JRamblersWalksfeedWalk {
    const EVENT = 'itemscope itemprop=event itemtype="http://schema.org/Event"';
    const PLACE = 'itemscope itemprop=event itemtype="http://schema.org/Place"';
    const GEOCOORDS = 'itemscope itemtype="http://schema.org/GeoCoordinates"';
    const GEOSHAPE = 'itemscope itemtype="http://schema.org/GeoShape"';

    public $walkDate;       // date of the walk as a datettime object
    public $title;          // title of the walk
    public $description;    // description of walk
    public $isLeader;       // is the contact info for the leader of the walk
    public $contactName;    // contact name
    public $email;          // email address for contact
    public $telephone1;     // first telephone number of contact
    public $telephone2;     // second telephone number of contact
    public $hasMeetingPlace;
    public $meetingPlaceExact;
    public $meetingLocation;
    public $meetingDesc;
    public $meetingTime;
    public $startingPlaceExact;
    public $startLocation;
    public $startDesc;
    public $nationalGrade;
    public $localGrade;
    public $distanceMiles;
    public $distanceKm;
    public $startTme;
    public $detailsPageUrl; // url to access the ramblers.org.uk page for this walk
    
    // extra derived values
    public $placeTag;
    public $eventTag;
    Public $dayofweek;
    public $day;
    public $month;

    const SORT_DATE = 0;
    const SORT_CONTACT = 1;
    const SORT_NATIONALGRADE = 2;
    const SORT_LOCALGRADE = 3;
    const SORT_DISTANCE = 4;
    const SORT_TELEPHONE1 = 5;
    const SORT_TELEPHONE2 = 6;

    function __construct($jsonitem) {
        //  $type = $jsonitem->type;
        if ($jsonitem != NULL) {
            $geometry = $jsonitem->geometry;
            $properties = $jsonitem->properties;
            $this->walkDate = DateTime::createFromFormat('l, d F Y H:i:s', $properties->date . $properties->time . ":00");
            $this->detailsPageUrl = $properties->url;
            $this->title = $properties->title;
            $this->description = $properties->summary;
            $this->nationalGrade = $properties->difficulty;
            $this->localGrade = "unknown";
            $this->distanceMiles = $properties->distance_miles;
            $this->distanceKm = $properties->distance_km;

            $this->isLeader = true;
            $this->contactName = "Fred A";
            $this->email = "email address";
            $this->telephone1 = "01332 123456";
            $this->telephone2 = "0871";
            $this->hasMeetingPlace = true;
            $this->meetingLocation = NULL;
            $this->meetingDesc = "DPDCP";
            $this->meetingTime = DateTime::createFromFormat('l, d F Y H:i:s', $properties->date . " 09:00:00");
            $this->startingPlaceExact = true;
            $this->startDesc = "start place";
            $this->startTime = DateTime::createFromFormat('l, d F Y H:i:s', $properties->date . " " . $properties->time . ":00");
            $this->startLocation = new JRamblersWalksfeedLocation($geometry->coordinates);
            if ($this->title == null) {
                $this->title = "???";
            }
            $this->createExtraData();
        }
    }

    function getValue($type) {
        switch ($type) {
            case self::SORT_CONTACT :
                return $this->contactName;
            case self::SORT_DATE:
                return $this->walkDate;
            case self::SORT_DISTANCE:
                return $this->distanceMiles;
            case self::SORT_LOCALGRADE:
                return $this->localGrade;
            case self::SORT_NATIONALGRADE:
                return $this->nationalGrade;
            case self::SORT_TELEPHONE1:
                return $this->telephone1;
            case self::SORT_TELEPHONE2:
                return $this->telephone2;
            default:
                return NULL;
        }
    }
    
    function createExtraData() {
        $this->dayofweek=$this->walkDate->format('l');
        $this->month=$this->walkDate->format('F');
        $this->day=$this->walkDate->format('jS');
        $this->eventTag=self::EVENT;
        $this->getSchemaPlaceTag();
    }
       function getSchemaPlaceTag() {
        $tag = "<div itemprop=location " . self::PLACE . " ><div style='display: none;' itemprop=name>" . $this->startDesc . "</div>";
        $latitude = $this->startLocation->latitude;
        $longitude = $this->startLocation->longitude;
        if ($this->startingPlaceExact) {
            $tag.= "<span itemprop=geo " . self::GEOCOORDS . ">  ";
            $tag.= "<meta itemprop=latitude content='" . $latitude . "' />";
            $tag.= "<meta itemprop=longitude content='" . $longitude . "' />";
        } else {
            $tag.= "<span itemprop=geo " . self::GEOSHAPE . ">  ";
            $tag.= "<meta itemprop=circle content='" . $latitude . "," . $longitude . ",1000' /> ";
        }

        $tag.= "</span> ";
        $tag.= "</div>";
        $this->placeTag= $tag;
    }

    function __destruct() {
        
    }

}





