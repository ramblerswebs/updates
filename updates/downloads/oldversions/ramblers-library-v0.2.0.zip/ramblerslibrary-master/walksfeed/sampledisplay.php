<?php
/**
 * Description of WalksDisplay
 *
 * @author Chris Vaughan
 */
 // no direct access
defined( "_JEXEC" ) or die( "Restricted access" );

class WalksDisplay {

    private $lastValue = "";

    const BR = "<br />";
 
       function DisplayWalks($walks, $option) {
        echo "</p>";
        switch ($option) {
            case "programme":
                $this->WalksProgramme($walks);
                break;
            case "programmetable":
                $this->WalksProgrammeTable($walks);
                break;
            case "leaderschecklist":
                $this->LeadersCheckList($walks);
                break;
            case "changedwalks":
                $this->WalksProgramme($walks);
                break;
            case "newspaper":
                $this->NewsPaper($walks);
                break;
            case "walksfeed":
                $this->WalksFeed($walks);
                break;
            case "derbyprogrammetable":
                $this->DerbyWalksProgrammeTable($walks);
                break;
            case "derbyprogramme":
                $this->DerbyWalksProgramme($walks);
                break;
            case "derbyleaderschecklist":
                $this->DerbyLeadersCheckList($walks);
                break;
            default:
                echo "<p>Invalid option supplied : " . $option . "</p>" . PHP_EOL;
        }
        echo "<p>";
    }

    function LeadersCheckList($walks) {
        $this->displayLeaders($walks);
        $walks->sort(JRamblersWalksfeedWalk::SORT_CONTACT, JRamblersWalksfeedWalk::SORT_DATE, NULL);
        $items = $walks->allWalks();
        $this->lastvalue = "";
        foreach ($items as $walk) {
            $thiscontact = $walk->contactName . "  " . $walk->telephone1;
            if ($thiscontact <> $this->lastvalue) {

                $this->lastvalue = $thiscontact;
                echo "<h1>", "List of walks for " . $thiscontact . "</h1>";
                echo "<p>Please <b>check the details</b> and contact the Prog Sec if any changes are required</p>" . PHP_EOL;
            }
            echo $this->displayWalkDetails($walk);

            echo "<b>Entry for Walks Programme Booklet</b>: " . PHP_EOL;
            $this->displayWalkForProgramme($walk);
            echo "<hr/>" . PHP_EOL;
        }
    }

    function DerbyLeadersCheckList($walks) {
        $this->displayLeaders($walks);
        $walks->sort(JRamblersWalksfeedWalk::SORT_CONTACT, JRamblersWalksfeedWalk::SORT_DATE, NULL);
        $items = $walks->allWalks();
        $this->lastvalue = "";
        foreach ($items as $walk) {
            $thiscontact = $walk->contactName . "  " . $walk->telephone1;
            if ($thiscontact <> $this->lastvalue) {
                $this->lastvalue = $thiscontact;
                echo "<h1>List of walks for " . $thiscontact . "</h1>" . PHP_EOL;
                echo "<p>Please <b>check the details</b> and contact the Prog Sec if any changes are required</p>" . PHP_EOL;
            }
            echo $this->displayWalkDetails($walk);

            echo "<b>Entry for Walks Programme Booklet</b>: " . PHP_EOL;
            echo "<table>" . PHP_EOL;
            $this->displayDerbyWalkForProgramme($walk);
            echo "</table>" . PHP_EOL;
            echo "<p>  </p>" . PHP_EOL;
            echo "<p>  </p><hr/>" . PHP_EOL;
        }
    }

    function DerbyWalksProgramme($walks) {

        $walks->sort(JRamblersWalksfeedWalk::SORT_DATE, NULL, NULL);
        $items = $walks->allWalks();

        foreach ($items as $walk) {
            $thismonth = $walk->walkDate->format('F');
            if ($thismonth <> $this->lastValue) {
                if ($this->lastValue <> "") {
                    echo "</table>" . PHP_EOL;
                }
                $this->lastValue = $thismonth;
                echo "<h2>" . $thismonth . "</h2>" . PHP_EOL;
                echo "<table>" . PHP_EOL;
            }

            $this->displayDerbyWalkForProgramme($walk);
        }
        echo "</table>" . PHP_EOL;
        $no = $this->nowalks($walks);
        echo "<p>Number of walks: " . $no . "</p>" . PHP_EOL;
        $this->displayLeaders($walks);
    }

    function WalksProgramme($walks) {

        $walks->sort(JRamblersWalksfeedWalk::SORT_DATE, NULL, NULL);
        $items = $walks->allWalks();

        foreach ($items as $walk) {
            $thismonth = $walk->walkDate->format('F');
            if ($thismonth <> $this->lastValue) {
                $this->lastValue = $thismonth;
                echo "<h2>" . $thismonth . "</h2>" . PHP_EOL;
            }

            $this->displayWalkForProgramme($walk);
        }
        $no = $this->nowalks($walks);
        echo "<p>Number of walks: " . $no . "<p>" . PHP_EOL;
        $this->displayLeaders($walks);
    }

    function WalksProgrammeTable($walks) {

        $walks->sort(JRamblersWalksfeedWalk::SORT_DATE, NULL, NULL);
        $items = $walks->allWalks();
        echo "<table>";
        echo JRamblersHtml::addTableHeader(array("Date", "Meet", "Start", "Title", "Distance", "Grade", "Leader"));
        foreach ($items as $walk) {
            $this->displayWalkForProgrammeTable($walk, false);
        }
        echo "</table>" . PHP_EOL;
        $no = $this->nowalks($walks);
        echo "<p>Number of walks: " . $no . "</p>" . PHP_EOL;
        $this->displayLeaders($walks);
    }

    function DerbyWalksProgrammeTable($walks) {

        $walks->sort(JRamblersWalksfeedWalk::SORT_DATE, NULL, NULL);
        $items = $walks->allWalks();
        echo "<table>";
        echo JRamblersHtml::addTableHeader(array("Date", "Meet", "Start", "Title", "Distance", "Grade", "Leader"));
        foreach ($items as $walk) {
            $this->displayDerbyWalkForProgrammeTable($walk, false);
        }
        echo "</table>" . PHP_EOL;
        $no = $this->nowalks($walks);
        echo "<p>Number of walks: " . $no . "</p>" . PHP_EOL;
        $this->displayLeaders($walks);
    }

    function WalksFeed($walks) {


        $walks->sort(JRamblersWalksfeedWalk::SORT_DATE, NULL, NULL);
        $items = $walks->allWalks();
        $no = 0;
        echo "<ul class=walksfeed >" . PHP_EOL;

        foreach ($items as $walk) {
            $now = new DateTime();
            if ($walk->walkDate > $now) {

                $no+=1;
                if ($no > 5) {
                    break;
                }

                $date = "<b>" . $walk->walkDate->format('D, jS F') . "</b>";
                $col2 = "<span itemprop=startDate content=" . $walk->walkDate->format(DateTime::ISO8601) . ">" . $date . "</span>";
                $col2 .= ", <span itemprop=name>" . $walk->title;
                $col2 .= ", " . $walk->distanceMiles . "m/" . $walk->distanceKm . "km</span>";
                $tag = $walk->placeTag;

                echo "<li class='walk' " . $walk->eventTag . "><a href='" . $walk->detailsPageUrl . "' target='_blank' >" . $col2 . $tag . "</a>" . PHP_EOL;
            }
        }
        echo "</ul>" . PHP_EOL;
    }

    function NewsPaper($walks) {

        $walks->sort(JRamblersWalksfeedWalk::SORT_DATE, NULL, NULL);
        $items = $walks->allWalks();

        foreach ($items as $walk) {
            $this->displayWalkForNewspaper($walk);
        }
    }

    private function displayLeaders($walks) {
        $walks->sort(JRamblersWalksfeedWalk::SORT_CONTACT, JRamblersWalksfeedWalk::SORT_TELEPHONE1, NULL);
        $items = $walks->allWalks();
        $last = "";
        echo "<h1>List of Walks Leaders</h1>" . PHP_EOL;
        echo "<ul>" . PHP_EOL;
        foreach ($items as $walk) {
            $value = $walk->contactName . " - " . $walk->telephone1;
            if (!$walk->telephone2 == NULL) {
                $value.=" ," . $walk->telephone2;
            }
            if ($value <> $last) {
                echo "<li>" . $value . "</li>" . PHP_EOL;
                $last = $value;
            }
        }
        echo "</ul>" . PHP_EOL;
    }

    private function nowalks($walks) {
        return count($walks->allWalks());
    }

    private function displayDerbyWalkForProgramme($walk) {
        $col1 = '<img border="0" src="http://nextprogramme.derbyramblers.org.uk/images/boots/bootblack.jpg" width="20" height="20">';
        $col2 = "<b>" . $walk->walkDate->format('l, jS') . "</b>" . PHP_EOL;
        if ($walk->hasMeetingPlace) {
            $col2 .= ", " . $walk->meetingTime->format('ga') . " at " . $walk->meetingDesc;
        }
        if ($walk->startingPlaceExact) {
            $col2 .= ", " . $walk->startTime->format('ga') . " at " . $walk->startDesc;
        }

        $col2 .= ", " . $walk->title . " ";
        $col2 .= ", " . $walk->distanceMiles . "m / " . $walk->distanceKm . "km";
        if ($walk->isLeader) {
            $col2.=", Leader " . $walk->contactName . " " . $walk->telephone1;
        } else {
            $col2.=", Contact " . $walk->contactName . " " . $walk->telephone1;
        }
        echo JRamblersHtml::addTableRow(array($col1, $col2));
    }

    private function displayWalkForProgramme($walk) {

        $col2 = "<b>" . $walk->walkDate->format('l, jS') . "</b>" . PHP_EOL;


        if ($walk->hasMeetingPlace) {
            $col2 .= ", " . $walk->meetingTime->format('ga') . " at " . $walk->meetingDesc;
        }
        if ($walk->startingPlaceExact) {
            $col2 .= ", " . $walk->startTime->format('ga') . " at " . $walk->startDesc;
        }

        $col2 .= ", " . $walk->title . " ";
        $col2 .= ", " . $walk->distanceMiles . "m / " . $walk->distanceKm . "km";
        if ($walk->isLeader) {
            $col2.=", Leader " . $walk->contactName . " " . $walk->telephone1;
        } else {
            $col2.=", Contact " . $walk->contactName . " " . $walk->telephone1;
        }

        echo "<p>" . $col2 . "</p>" . PHP_EOL;
    }
  private function displayWalkForNewspaper($walk) {

        $col2 = "<b>" . $walk->walkDate->format('F l, jS') . "</b>" . PHP_EOL;


        if ($walk->hasMeetingPlace) {
            $col2 .= ", " . $walk->meetingTime->format('ga') . " at " . $walk->meetingDesc;
        }
        if ($walk->startingPlaceExact) {
            $col2 .= ", " . $walk->startTime->format('ga') . " at " . $walk->startDesc;
        }

        $col2 .= ", " . $walk->title . " ";
        $col2 .= ", " . $walk->distanceMiles . "m / " . $walk->distanceKm . "km";
        if ($walk->isLeader) {
            $col2.=", Leader " . $walk->contactName . " " . $walk->telephone1;
        } else {
            $col2.=", Contact " . $walk->contactName . " " . $walk->telephone1;
        }

        echo "<p>" . $col2 . "</p>" . PHP_EOL;
    }

    private function displayWalkForProgrammeTable($walk) {

        $date = "<b>" . $walk->walkDate->format('l, jS F') . "</b>" . PHP_EOL;

        if ($walk->hasMeetingPlace) {
            $meet = $walk->meetingTime->format('ga') . " at " . $walk->meetingDesc;
        } else {
            $meet = ".";
        }
        if ($walk->startingPlaceExact) {
            $start = $walk->startTime->format('ga') . " at " . $walk->startDesc;
        } else {
            $start = ".";
        }

        $title = $walk->title . " ";
        $dist = $walk->distanceMiles . "m / " . $walk->distanceKm . "km";
        if ($walk->isLeader) {
            $contact = $walk->contactName . " " . $walk->telephone1;
        } else {
            $contact = $walk->contactName . " " . $walk->telephone1;
        }
        $grade = $walk->nationalGrade . self::BR . $walk->localGrade;

        echo JRamblersHtml::addTableRow(array($date, $meet, $start, $title, $dist, $grade, $contact));
    }

    private function displayDerbyWalkForProgrammeTable($walk) {
        $col1 = '<img border="0" src="http://nextprogramme.derbyramblers.org.uk/images/boots/bootblack.jpg" width="20" height="20">';

        $date = "<b>" . $walk->walkDate->format('l, jS F') . "</b>" . PHP_EOL;
        if ($walk->hasMeetingPlace) {
            $meet = $walk->meetingTime->format('ga') . " at " . $walk->meetingDesc;
        } else {
            $meet = ".";
        }
        if ($walk->StartingPlaceExact) {
            $start = $walk->startTime->format('ga') . " at " . $walk->startDesc;
        } else {
            $start = ".";
        }

        $title = $walk->title . " ";
        $dist = $walk->distanceMiles . "m / " . $walk->distanceKm . "km";
        if ($walk->isLeader) {
            $contact = $walk->contactName . " " . $walk->telephone1;
        } else {
            $contact = $walk->contactName . " " . $walk->telephone1;
        }
        $grade = $walk->nationalGrade . self::BR . $col1;

        echo JRamblersHtml::addTableRow(array($date, $meet, $start, $title, $dist, $grade, $contact));
    }

    private function displayWalkDetails($walk) {

        $out = "<h2>" . $walk->walkDate->format('l, jS F Y') . "</h2>" . self::BR . PHP_EOL;
        $out .= "<b>Title</b>: " . $walk->title . self::BR . PHP_EOL;
        $out .= "<b>Description</b>: " . $walk->description . self::BR . PHP_EOL;
        $out .= "<b>Distance</b>: " . $walk->distanceMiles . "m / " . $walk->distanceKm . "km" . self::BR . PHP_EOL;
        if ($walk->hasMeetingPlace) {
            $out .= "<b>Meeting place</b>: " . $walk->meetingTime->format('ga') . " at " . $walk->meetingDesc . self::BR . PHP_EOL;
        } else {
            $out.="No meeting place specified" . self::BR . PHP_EOL;
        }
        if ($walk->startingPlaceExact) {
            $out .= "<b>Starting Place</b>: " . $walk->startTime->format('ga') . " at " . $walk->startDesc . self::BR . PHP_EOL;
        } else {
            $out.="No starting place specified" . self::BR . PHP_EOL;
        }

        $out .= "<b>National Grade</b>: " . $walk->nationalGrade . self::BR . PHP_EOL;
        $out .= "<b>Local Grade</b>: " . $walk->localGrade . self::BR . PHP_EOL;
        $out.="<p></p>";

        return $out;
    }

}
