<?php

/*
 * Delete a waiting list entry
 *      Parameters
 * 
 *        ewid - id of event
 *        userMd5email - the email
 *        
 * 
 *      url
 *         index.php?option=com_ra_eventbooking&view=admindeletesinglewait&format=json
 * 
 * EW     an RA event or walk in ramblers library format
 * ESC    a collection of booking records , EVB
 * EVB    a booking record for an event, an object
 * NBI    a new booking information for one user
 * BLC    a collection of bookings, collection of BLI
 * BLI    the user information booking for a user
 * WLC    a collection of waiting records, collection of WLI
 * WLI    the user information about someone on waiting list
 */

namespace Ramblers\Component\Ra_eventbooking\Site\View\Admindeletesinglewait;

use \Ramblers\Component\Ra_eventbooking\Site\Helper\Ra_eventbookingHelper as helper;
use Joomla\CMS\Response\JsonResponse;
use Joomla\CMS\MVC\View\JsonView as BaseJsonView;

// No direct access
defined('_JEXEC') or die;

class JsonView extends BaseJsonView {

    public function display($tpl = null) {
        try {
            $feedback = [];
            $data = helper::getPostedData();
            $md5Email = $data->md5Email;
            $ewid = $data->ewid;

            $ebRecord = helper::getEVBrecord($ewid, "Internal");
            $ebRecord->removeWaiting($md5Email);
            $ebRecord->updateDatabase('Waiting');
            $feedback[] = '<h3>The notification list entry for this event has been removed</h3>';

            // return status of change
            $record = (object) [
                        'feedback' => $feedback
            ];
            echo new JsonResponse($record);
        } catch (Exception $e) {
            echo new JsonResponse($e);
        }
    }
}
