CREATE TABLE IF NOT EXISTS `#__ra_event_bookings` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`modified_by` INT(11)  NULL  DEFAULT 0,
`event_id` VARCHAR(255) NOT NULL ,
`booking_data` LONGTEXT NULL ,
`waiting_data` LONGTEXT NULL ,
`event_data` LONGTEXT NULL ,
`created_by` INT(11) NULL DEFAULT 0,
`creation_date` DATETIME NULL DEFAULT NULL ,
`params` text NOT NULL,
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_modified_by` (`modified_by`)
,KEY `idx_created_by` (`created_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;



INSERT INTO `#__content_types` (`type_title`, `type_alias`, `table`, `rules`, `field_mappings`, `content_history_options`)
SELECT * FROM ( SELECT 'Event setting','com_ra_eventbooking.eventsetting','{"special":{"dbtable":"#__ra_event_bookings","key":"id","type":"EventsettingTable","prefix":"Joomla\\\\Component\\\\Ra_eventbooking\\\\Administrator\\\\Table\\\\"}}', CASE 
                                    WHEN 'rules' is null THEN ''
                                    ELSE ''
                                    END as rules, CASE 
                                    WHEN 'field_mappings' is null THEN ''
                                    ELSE ''
                                    END as field_mappings, '{"formFile":"administrator\/components\/com_ra_eventbooking\/forms\/eventsetting.xml", "hideFields":["checked_out","checked_out_time","params","language" ,"payment_details"], "ignoreChanges":["modified_by", "modified", "checked_out", "checked_out_time"], "convertToInt":["publish_up", "publish_down"], "displayLookup":[{"sourceColumn":"catid","targetTable":"#__categories","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"group_id","targetTable":"#__usergroups","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"created_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"},{"sourceColumn":"access","targetTable":"#__viewlevels","targetColumn":"id","displayColumn":"title"},{"sourceColumn":"modified_by","targetTable":"#__users","targetColumn":"id","displayColumn":"name"}]}') AS tmp
WHERE NOT EXISTS (
	SELECT type_alias FROM `#__content_types` WHERE (`type_alias` = 'com_ra_eventbooking.eventsetting')
) LIMIT 1;
-- Mail Templates install SQL for com_ra_eventbooking
-- Generated for Joomla 5

INSERT INTO `#__mail_templates`
  (`template_id`, `extension`, `language`, `subject`, `body`, `htmlbody`, `attachments`, `params`)
VALUES
  ('com_ra_eventbooking.email_bookers', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKERS_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKERS_BODY', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKERS_HTMLBODY', '', '{"tags":["ATTENDEES","EMAILCONTENT","EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","FOOTER","GROUPNAME","SIGNATURE","TONAME","VIEWBUTTON"]}'),
  ('com_ra_eventbooking.email_booking_contact', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKING_CONTACT_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKING_CONTACT_BODY', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKING_CONTACT_HTMLBODY', '', '{"tags":["EMAILCONTENT","EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","FOOTER","GROUPNAME","REPLYTONAME","TONAME","VIEWBUTTON"]}'),
  ('com_ra_eventbooking.email_booking_list', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKING_LIST_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKING_LIST_BODY', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKING_LIST_HTMLBODY', '', '{"tags":["BOOKINGLIST","EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","FOOTER","GROUPNAME","REASON","SIGNATURE","TONAME","VIEWBUTTON","WAITINGLIST"]}'),
  ('com_ra_eventbooking.email_booking_list_closed', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKING_LIST_CLOSED_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKING_LIST_CLOSED_BODY', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_BOOKING_LIST_CLOSED_HTMLBODY', '', '{"tags":["BOOKINGLIST","EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","FOOTER","GROUPNAME","SIGNATURE","TONAME","VIEWBUTTON","WAITINGLIST"]}'),
  ('com_ra_eventbooking.email_waiting', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_WAITING_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_WAITING_BODY', 'COM_RA_EVENTBOOKING_MAIL_EMAIL_WAITING_HTMLBODY', '', '{"tags":["EMAILCONTENT","EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","FOOTER","GROUPNAME","SIGNATURE","TONAME","VIEWBUTTON"]}'),
  ('com_ra_eventbooking.event_changed', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_EVENT_CHANGED_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_EVENT_CHANGED_BODY', 'COM_RA_EVENTBOOKING_MAIL_EVENT_CHANGED_HTMLBODY', '', '{"tags":["ATTENDEES","EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","EVENTTYPE","FOOTER","GROUPNAME","SIGNATURE","TONAME","VIEWBUTTON"]}'),
  ('com_ra_eventbooking.new_booking', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_NEW_BOOKING_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_NEW_BOOKING_BODY', 'COM_RA_EVENTBOOKING_MAIL_NEW_BOOKING_HTMLBODY', '', '{"tags":["ATTENDEES","BOOKINGEMAILTEXT","CANCELBUTTON","EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","EVENTTYPE","FOOTER","GROUPNAME","PAYMENT","SIGNATURE","TONAME","VIEWBUTTON"]}'),
  ('com_ra_eventbooking.notify_list_email', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_NOTIFY_LIST_EMAIL_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_NOTIFY_LIST_EMAIL_BODY', 'COM_RA_EVENTBOOKING_MAIL_NOTIFY_LIST_EMAIL_HTMLBODY', '', '{"tags":["EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","FOOTER","GROUPNAME","NOOFPLACES","SIGNATURE","TONAME","VIEWBUTTON"]}'),
  ('com_ra_eventbooking.remove_booking', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_REMOVE_BOOKING_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_REMOVE_BOOKING_BODY', 'COM_RA_EVENTBOOKING_MAIL_REMOVE_BOOKING_HTMLBODY', '', '{"tags":["EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","EVENTTYPE","FOOTER","GROUPNAME","SIGNATURE","TONAME","VIEWBUTTON"]}'),
  ('com_ra_eventbooking.verify_email', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_VERIFY_EMAIL_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_VERIFY_EMAIL_BODY', 'COM_RA_EVENTBOOKING_MAIL_VERIFY_EMAIL_HTMLBODY', '', '{"tags":["FOOTER","SIGNATURE","TONAME","VERIFYCODE"]}'),
  ('com_ra_eventbooking.waiting_add', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_WAITING_ADD_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_WAITING_ADD_BODY', 'COM_RA_EVENTBOOKING_MAIL_WAITING_ADD_HTMLBODY', '', '{"tags":["EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","FOOTER","GROUPNAME","SIGNATURE","TONAME","VIEWBUTTON"]}'),
  ('com_ra_eventbooking.waiting_delete', 'com_ra_eventbooking', '', 'COM_RA_EVENTBOOKING_MAIL_WAITING_DELETE_SUBJECT', 'COM_RA_EVENTBOOKING_MAIL_WAITING_DELETE_BODY', 'COM_RA_EVENTBOOKING_MAIL_WAITING_DELETE_HTMLBODY', '', '{"tags":["EVENTDATE","EVENTDESCRIPTION","EVENTID","EVENTTITLE","FOOTER","GROUPNAME","SIGNATURE","TONAME","VIEWBUTTON"]}');