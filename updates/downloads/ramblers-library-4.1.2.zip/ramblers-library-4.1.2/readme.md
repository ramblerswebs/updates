Ramblers library to process and display json walks feeds

See wiki for details https://github.com/ramblerswebs/ramblers-library/wiki

Updates
3.0.0

    Convert into Joomla Library

2.0.0 

    update feed handling to use old cache file if unable to read feed

    updates to leaflet mapping

            Google licensing

            Add fix to make sure drop down menu does not go under map

        addition of postcode display

        display right click points location including mapcode

        full screen option

        different location search engine

    new gpx mapping option

        add imperial option

        add line colour option

    new sx05 programme display method

    new feed option to limit walks by distance

    correction to feed filterGroups option

    change to make filterDateRange to be inclusive
