Plug in to enable Ramblers class library
version 1.5.0
    Correction to enable classes to work in administrator 
