var L, document, ramblersMap;
ramblersMap=new RamblersLeafletMap('[base]');
// [set addGoogle]
// [set MapOptions]
window.onload = function () {
    raLoadLeaflet();
};