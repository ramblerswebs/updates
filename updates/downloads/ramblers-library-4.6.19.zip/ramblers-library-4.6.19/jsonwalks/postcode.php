<?php

/**
 * Description of postcode
 *
 * @author Chris Vaughan
 */
class RJsonwalksPostcode {

    public $text = "";
    public $latitude = 0;
    public $longitude = 0;
    public $direction = "Unknown";
    public $distance = 9999999;

}
