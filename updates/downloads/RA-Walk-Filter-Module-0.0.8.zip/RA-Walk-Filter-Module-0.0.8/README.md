RA Walks Filter Module

Allows the filtering of walks when viewing via FullDetails2 this may change