<?php

/**
 * @version		0.0
 * @package		Simple JSON Feed reader
 * @author              Chris Vaughan Ramblers-webs.org.uk
 * @copyright           Copyright (c) 2014 Chris Vaughan. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 */
// no direct access
defined('_JEXEC') or die('Restricted access');

class JRamblersWalksfeedDisplay {

    private $clearCache = false;

// Conventions

    function Display($rafeedurl, $displayhelper, $option) {

// API
        $mainframe = JFactory::getApplication();
        $document = JFactory::getDocument();
        $db = JFactory::getDBO();
        $user = JFactory::getUser();
        $aid = $user->get('aid');

// Assign paths
        $sitePath = JPATH_SITE;
        $siteUrl = substr(JURI::base(), 0, -1);

        $feedTimeout = 5;
        $CacheTime = 60; // minutes
        $cacheLocation = $this->CacheLocation();

// Fetch content
        $srfr = new JRamblersFeedhelper($cacheLocation, $CacheTime);

        if ($this->clearCache == true) {
            $srfr->clearCache(); // clear cache
        }
        $contents = $srfr->getFeed($rafeedurl);

        if ($contents != "") {
            if (file_exists($displayhelper)) {
               // require_once 'classes.php';
                require_once($displayhelper);

                $json = json_decode($contents);
                unset($contents);
                $walks = new JRamblersWalksfeedWalks($json);
                unset($json);
                $display = new WalksDisplay();
                $display->DisplayWalks($walks, $option);
                $display = NULL;
            } else {
                echo '<pre>Group display helper file not found -' . $displayhelper . '</pre>';
            }
        } else {
            echo '<pre>RA Feed file not found , read error or is empty</pre>';
        }
    }

    function ClearCache() {
        $this->clearCache = true;
    }

    private function CacheLocation() {
        if (!defined('DS')) {
            define('DS', DIRECTORY_SEPARATOR);
        }
        return 'cache' . DS . 'ra_feed';
    }

}
