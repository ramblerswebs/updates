<!DOCTYPE html>
<html>
    <body>

        <?php
        echo "The time is "  . date("H:i:s");
        ?>

    </body>
</html> 

